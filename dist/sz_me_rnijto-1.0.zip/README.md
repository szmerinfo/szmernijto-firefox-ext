# szmernijto-firefox-ext

Wtyczka została stworzona do szybszego publikowania treści na instancji lemmiego [szmer.info](https://szmer.info)

Do uruchomienia potrzebna jest przeglądarka oparta firefox w wersji przynajmniej 87.

## Instalacja

1. Pobierz [zip](https://github.com/szmerinfo/szmernijto-firefox-ext/archive/refs/heads/main.zip) z plikami wtyczki
2. Rozpakuj zip gdzieś na swoim dysku
3. Uruchom przeglądarkę Firefox
4. Przejdź do ustawień rozszerzeń (Ctrl+shift+A)
5. W opcjach które sięp pojawią wybierz "Załaduj rozpakowane" i wskaż rozpakowane pliki z zipa
6. W ustawieniach rozszerzeń przypnij Szmernijto do paska i gotowe

## Prywatność

Wtyczka nie zbiera żadnych informacji o użytkowniku, jej podstawową funkcją jest przekierowanie ze strony,
którą chcemy się podzielić na stronę szmer.info i uzupełnienie formularza dodawania nowego postu.

Wtyczka wykorzystuje api szmer.info (iframely) do pobrania informacji o stronie szerowanej.
